//
// Created by Fungai Jani on 19/9/2022.
//
#include <stdio.h>
#include <iostream>
#include "Date.h"

using namespace std;

Date:: Date(int day_, int month_, int year_) throw(logic_error)
        :  day(day_), month(month_), year(year_)
{
    day = day_;

    if (month <= 0){
        throw logic_error("Month too low");
    }
    if (month > 12) {
        throw logic_error("Month too high");
    }
    month = month_;

    year = year_;
}

Date :: Date() {
    time_t now = time(NULL);
    struct tm  *current = localtime(&now);

    day = current->tm_mday;
    month = current -> tm_mon + 1;
    year = current-> tm_year + 1900;
}

int Date:: getDay() const {
    return day;
}

int Date :: getMonth() const {
    return month;
}

int Date :: getYear() const {
    return year;
}

void Date::showStructure() const {
    // Outputs data in same form as operator<<.
    // NOTE: could do "cout << *this << endl", but that would not compile
    // if operator<< has not been defined.
    cout << month << "/" << day << "/" << year << endl;
}

bool Date :: isLeapYear(int year) {
    if ((year  % 400 == 0 || (year % 100 != 0 && year % 4  == 0)))
        return true;
    else
        return false;
}

int  Date::daysInMonth(int month, int year)  {
    if(month == 2)
    {
        if ((year  % 400 == 0 || (year % 100 != 0 && year % 4  == 0)))
        return 29;
        else
            return 28;
    }
    else if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 ||month == 10 || month == 12 )
        return 31;
    else
        return 30;
}
ostream& operator<<(ostream& out, const Date& date) {
    out << date.month; out << "/"; out << date.day; out << "/"; out << date.year;
    return out;
}
