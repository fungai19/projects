//
// Created by Fungai Jani on 19/9/2022.
//
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <cassert>
#include <cstring>
#include "Text.h"

Text:: Text ( const char *charSeq )
{
    bufferSize = strlen(charSeq) + 1;   // Account for null

    try
    {
        buffer = new char [ bufferSize ];   // Allocate memory
    }
    catch ( bad_alloc &e )
    {
        cerr << "Text::Text(const char): bad_alloc: buffer == 0\n";
        throw bad_alloc();
    }

    strcpy(buffer,charSeq);             // Copy the string
}

Text:: Text ( const Text &valueText )
        : bufferSize(valueText.bufferSize)
{
    buffer = new char [bufferSize];
    strcpy(buffer, valueText.buffer);
}

//--------------------------------------------------------------------
void Text:: operator = ( const Text& other )
// Assigns other to a Text object.

{
    if (this != &other) {
        int rlen = other.getLength();   // Length of other

        if ( rlen >= bufferSize )       // If other will not fit
        {
            delete [] buffer;            // Release buffer and
            bufferSize = rlen + 1;             //  allocate a new
            buffer = new char [ bufferSize ];  //  (larger) buffer
        }

        strcpy(buffer, other.buffer);    // Copy other’s buffer
        bufferSize = other.bufferSize;  // Copy other’s bufferSize
    }
}

//--------------------------------------------------------------------
Text:: ~Text ()
{
    delete [] buffer;
}


//--------------------------------------------------------------------
int Text:: getLength () const
{
    return bufferSize - 1;
}

ostream & operator << ( ostream &output, const Text &outputText )
{
    output << outputText.buffer;
    return output;
}


