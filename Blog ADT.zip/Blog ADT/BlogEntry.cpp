//
// Created by Fungai Jani on 19/9/2022.
//
#include <stdio.h>
#include <stdexcept>
#include <iostream>
#include "BlogEntry.h"

using namespace std;
BlogEntry ::BlogEntry() {}

BlogEntry :: BlogEntry(const Text& initAuthor, const Text& initContents)
            : author(initAuthor), contents(initContents)
{

}

Text BlogEntry ::getAuthor() const {
    return author;
}
Text BlogEntry ::getContents() const {
    return contents;
}

Date BlogEntry :: getCreateDate() const {
    return created;
}

Date BlogEntry ::getModifyDate() const {
    return modified;
}

void BlogEntry ::setAuthor(const Text &newAuthor) {
    author = newAuthor;
}

void BlogEntry ::setContents(const Text &newContents) {
        contents = newContents;
}

void BlogEntry::showStructure() const {
    cout << "Author: " << author << endl;
    cout << "Created: " << created << endl;
    cout << "Modified: " << modified << endl;
    cout << "Content: " << contents << endl;
}

void BlogEntry :: printHTML( ostream& out ) const {
    out << "<html>" << endl;
    out << "<body>" << endl;
    out << "<h1> " << getAuthor() << endl;
    out << "<p>" << endl;
    out << getContents() << endl;
    out << "</p>" << endl;
    out << "<p>" << endl;
    out << "Created: " << getCreateDate() << endl;
    out << "</p>" <<endl;
    out << "<p>" <<endl;
    out << "Last modified: " << getModifyDate() << endl;
    out << "</p>" <<endl;
    out << "</body>" <<endl;
    out << "</html>" <<endl;
}
