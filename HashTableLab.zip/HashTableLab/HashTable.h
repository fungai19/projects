//
// Created by Fungai Jani on 14/11/2022.
//

#ifndef HASHTABLELAB_HASHTABLE_H
#define HASHTABLELAB_HASHTABLE_H
#include <iostream>
#include <vector>
#include <list>
#include <string>

using namespace std;



class HashTable {

private:
    vector<list<string>> table;

public:

    static const int TABLE_MAX_SIZE = 13;

    HashTable(int maxSize = HashTable::TABLE_MAX_SIZE);

    ~HashTable();

    void insert (string item);

    friend ostream& operator<<(ostream &out, const HashTable &hashTable);


};




#endif //HASHTABLELAB_HASHTABLE_H
