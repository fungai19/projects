#include <fstream>
#include <iostream>
#include <vector>
#include <list>
#include <string>
#include <algorithm>


#include "HashTable.h"

using namespace std;


int main() {
    HashTable myTable; //Hashtable
    ifstream file; // file for the hashtable
    string filename, temp1; //Name of the hashtable file

    // Read the hashtable from the specified file.

    cout << "Enter file name : " ;
    cin >> filename;

    file.open(filename.c_str()); // Open the file

    if (file.is_open()) {
        // Read in the words/strings one-by-one.
        while (file >> temp1) {
            // temp1 is the most recently read word/string
            myTable.insert(temp1);
        }
        //print out the hashtable.
        cout << "Here is your hashtable: " << endl;
        cout << myTable << endl;

        // Close the file.
        file.close();
    }

    else {
        //If the file is not found or cannot be opened
        // and print an error message
        cout << "Error in opening the file" << endl;
    }



    return 0;
}