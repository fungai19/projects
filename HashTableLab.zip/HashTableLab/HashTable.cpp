//
// Created by Fungai Jani on 14/11/2022.
//

#include <iostream>
#include "HashTable.h"

using namespace std;


//Default constructor

HashTable::HashTable(int maxSize): table(TABLE_MAX_SIZE)
//Pre: None
//Post: Creates a list
{

}


//Destructor

HashTable::~HashTable()
//Pre: None
//Post: Frees up the memory of the list
{

}

// Checks if the item already exists in the list.
// If it does not, then adds it to the list.

void HashTable::insert (string item)
// Pre : None
// Post: Inserts new string item to the list
{
    int hash = 0;
    int index = 0;

    if (item.size() <= 2) {
        for (int i = 0; i <= item.size() ; ++i) {
            hash = hash + item[i];
        }
        index = hash % table.size();
        if (table[index].back() != item && table[index].front() != item){
            table[index].push_back(item);
        }
    }

    else {
        for (int i = 0; i <= 3; i++) {
            hash = hash + item[i];
        }
        index = hash % table.size();

        if (table[index].back() != item && table[index].front() != item){
            table[index].push_back(item);
        }
    }

}

// Outputs the Hashtable

ostream& operator<<(ostream &out, const HashTable &hashTable)
//Pre : None
// Post : Outputs the hashtable
{
    // find the index in the vector for a list
    for ( int i = 0; i < HashTable::TABLE_MAX_SIZE ; i++) {
        auto &temp = hashTable.table[i];
        out << "INDEX " << i << ": " ;
        // Iterate through the list
        for (auto j : temp ) {
            //Display the string one-by-one
            out <<  j << " ";
        }
        out << endl;
    }
    return out;
}


