//--------------------------------------------------------------------
//
//  		                                           ListArray.hpp
//  
//  Class declaration and implementation
//  for the array implementation of the List ADT
//
//--------------------------------------------------------------------

#ifndef LISTARRAY_HPP
#define LISTARRAY_HPP

#include <stdexcept>
#include <iostream>

using namespace std;

template < typename DataType >
class List
{
  public:

    static const int MAX_LIST_SIZE = 10;   // Default maximum list size

    // Constructors
    
    // Creates an empty list. Allocates enough memory for maxNumber
	// data items (defaults to MAX_LIST_SIZE).
    List ( int maxNumber = MAX_LIST_SIZE );	// Default constructor
    List ( const List& source );		// Copy constructor
    
    // Overloaded assignment operator
    List& operator= ( const List& source );

    // Destructor
    virtual ~List ();

    // List manipulation operations
    virtual void insert ( const DataType& newDataItem )  // Insert after cursor
	throw ( logic_error );  
    void remove () throw ( logic_error );        // Remove data item
    virtual void replace ( const DataType& newDataItem ) // Replace data item
	throw ( logic_error ); 
    void clear ();                               // Clear list

    // List status operations
    bool isEmpty () const;                    // List is empty
    bool isFull () const;                     // List is full
    int getSize() const;
    // List iteration operations
    void gotoBeginning ()                     // Go to beginning
        throw ( logic_error );
    void gotoEnd ()                           // Go to end
        throw ( logic_error );
    bool gotoNext ()                          // Go to next data item
        throw ( logic_error );
    bool gotoPrior ()                         // Go to prior data item
        throw ( logic_error );
    DataType getCursor () const
        throw ( logic_error );                // Return data item

    // Output the list structure -- used in testing/debugging
    virtual void showStructure () const;

    // these are not needed for this lab
    // void moveToNth ( int n )                  // Move data item to pos. n
    //    throw ( logic_error );  
    // bool find ( const DataType& searchDataItem )     // Find data item
    //    throw ( logic_error );  

  protected:

    // Data members
    int maxSize,
        size,             // Actual number of data item in the list
        cursor;           // Cursor array index
    DataType *dataItems;  // Array containing the list data item
};


// below this line, students implement the required methods
// the one-argument constructor is implemented for you as model

template <typename DataType>
List<DataType>::List ( int maxNumber ): 
maxSize(maxNumber),
size(0),
cursor(-1)
{   //Creates an empty list
    //Allocates enough memory for the list containing maxNumber data items
    dataItems = new DataType[maxSize];
}
template <typename DataType>
List<DataType>::~List() {
   // Pre: none
  //  Post: frees up the memory used to store the list.

    delete []dataItems;
}

template <typename DataType>
List<DataType>::List ( const List& source ) {
  //  Pre: none
  //  Post: Copy constructor. Makes a deep copy of the given list.

    maxSize = source.maxSize;
    size = source.size;
    cursor = source.cursor;
    for( int i=0; i<size; i++ ) {
        dataItems[i] = source.dataItems[i];
    }

}

template <typename DataType>
List<DataType>& List<DataType>:: operator= ( const List &source )

// Overloaded assignment operator. Resets a list object to contain a
// deep-copy of the provided model object, source.

{
    // Set buffer to correct size. If current buffer too small, allocate a new one.
    // NOTE: this also happens to protect against self-destruction.  Explicit
    // checks against &source vs. this will appear later (e.g. Stack).
    if( source.maxSize > maxSize ) {
        delete [] dataItems;
        dataItems = new DataType[maxSize];
    }

    maxSize = source.maxSize;
    size = source.size;
    cursor = source.cursor;

    for( int i=0; i<size; i++ ) {
        dataItems[i] = source.dataItems[i];
    }

    // Return an object reference to support multiple assignment.
    // E.g., "a = b = c".
    return *this;
}

template <typename DataType>
bool List<DataType>::isEmpty () const {
    //returns true if the list is empty and false if it is not
    // has no requirements for the function to implement
    if (size == 0) {
        return true;
    }
    return false;
}
    
template <typename DataType>    
bool List<DataType>::isFull () const{
    //function has  no requirements to implement
    //returns  true if the  list is  full and false if it is not.
	if (size == maxSize) {
        return true;
    }
    return false;
}

template <typename DataType>
int List<DataType>::getSize() const {
    //Returns the size of the list
    return size;
}

template <typename DataType>
void List<DataType>:: replace ( const DataType& newDataItem ) throw(logic_error) {
    //The list must not be empty
    //replace the item of choice by the cursor with newDataItem
    if(isEmpty())
        throw logic_error ("The list is empty");
    else
        dataItems[cursor] = newDataItem;
}

template <typename DataType>
void List<DataType>:: remove () throw ( logic_error ) {
 //   Pre: List is not empty
   // Post: Removes the data item marked by the cursor from the list.
    if (isEmpty())
        throw logic_error("The list is empty");
    else if (cursor == size-1) {
        cursor = 0;
        size--;
    }
    else {
        for (int i = cursor; i < size - 1; i++) {
            dataItems[i] = dataItems[i + 1];
        }
        size --;
    }
}

template <typename DataType>
void List<DataType>::clear() {
  //  Pre: none
   // Post: Removes all the data items in the list.
    while (!isEmpty()) {
        cursor--;
        size--;
    }
}

template <typename DataType>
void List<DataType>:: insert ( const DataType& newDataItem )  // Insert after cursor
throw ( logic_error )
{
   // Pre: List is not full.
  //  Post: Inserts newDataItem to the list.
    if (isFull())
        throw logic_error("The list is full");
    int i;
    for (i = size; i > cursor +1; i --){
        dataItems[i]=dataItems[i - 1];

    }
    size++;
    dataItems[++cursor]=newDataItem;
}

template <typename DataType>
void List<DataType>::  gotoBeginning ()                     // Go to beginning
throw ( logic_error )
{
    //The list must not be empty
    //moves the cursor to the value at the beginning of the list
    if (isEmpty() )
        throw logic_error("The list is empty");
    else
        cursor = 0;
}


template <typename DataType>
void List<DataType>:: gotoEnd ()                           // Go to end
throw ( logic_error ) {
    //The list must not be empty
    //moves the  cursor to the value at the end of the  list

    //The list must not be empty
    //moves the cursor to the value at the beginning of the list
    if (isEmpty() )
        throw logic_error("The list is empty");
    else
        cursor = size - 1;
}


template <typename DataType>
bool List<DataType>:: gotoNext ()                          // Go to next data item
throw ( logic_error ) {
//List must not be empty
    //moves the cursor to the next value if the cursor is not at the end of the list
    //moves the cursor to the first value if the current cursor is at the end of the list
    //returns true if done successfully
    if (isEmpty()){
        throw logic_error ("the list is empty");
    } else if(cursor < size) {
        cursor ++;
        return true;
    }
    else{
        return false;
    }

}

template <typename DataType>
bool List<DataType>:: gotoPrior ()                         // Go to prior data item
 throw ( logic_error ) {
    //List mus not be empty
    // Cursor must not be at the beginning of the list
    //Moves the cursor to the previous data item in the list if the cursor is not at the beginning of the list
    // Returns true if done successfully and false if it failed
    if (isEmpty()) {
        throw logic_error("the list is empty");
    } else if (cursor != 0) {
        cursor--;
    }
}

template <typename DataType>
DataType List<DataType>:: getCursor () const
throw ( logic_error ) {
    //List must not be empty
    //returns the value marked by the cursor
    if (isEmpty())
        throw logic_error ("the list is empty");
    else if (cursor<= size-1)
        return dataItems[cursor];

}
template <typename DataType>
void List<DataType>::  showStructure () const {
// outputs the data items in a list. if the list is empty, outputs
// "empty list". this operation is intended for testing/debugging
// purposes only.

    {
        int j;   // loop counter

        if ( size == 0 )
            cout << "empty list" << endl;
// The Ordered List code blows up below. Since this is just debugging
// code, we check for whether the OrderedList is defined, and if so,
// print out the key value. If not, we try printing out the entire item.
// Note: This assumes that you have used the double-inclusion protection
// in your OrderedList.cpp file by doing a "#ifndef ORDEREDLIST_CPP", etc.
// If not, you will need to comment out the code in the section under
// the "else", otherwise the compiler will go crazy in lab 4.
// The alternative is to overload operator<< for all data types used in
// the ordered list.
        else
        {
            cout << "size = " << size
                 <<  "   cursor = " << cursor << endl;
            for ( j = 0 ; j < maxSize ; j++ )
                cout << j << "\t";
            cout << endl;
            for ( j = 0 ; j < size ; j++ ) {
                if( j == cursor ) {
                    cout << "[";
                    cout << dataItems[j]
#ifdef ORDEREDLIST_CPP
                        .getKey()
#endif
                            ;
                    cout << "]";
                    cout << "\t";
                }
                else
                    cout << dataItems[j]
                         #ifdef ORDEREDLIST_CPP
                         .getKey()
                         #endif
                         << "\t";
            }
            cout << endl;
        }
    }
}



#endif

