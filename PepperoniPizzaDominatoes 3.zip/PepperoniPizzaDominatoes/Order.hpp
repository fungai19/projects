//
// Created by Owner on 12/5/22.
//

#ifndef PEPPERONIPIZZADOMINATOES_ORDER_HPP
#define PEPPERONIPIZZADOMINATOES_ORDER_HPP
#include "Time.hpp"
#include "Driver.hpp"
#include <iostream>
#include <iomanip>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <string>

using namespace std;
// include time header
class Order {

public:

    //Preconditions: none
    //Post conditions: creates default order
    Order();

    //Preconditions: none
    //Post conditions: creates order with orderTime t and info i
    Order(Time t, string i);

    //Preconditions: status is ordered
    //Post conditions: sets status to departed
    void depart() throw(logic_error);

    //Preconditions: none
    //Post conditions: sets deliveryTime to t, sets status to delivered
    void deliver(Time t);

    //Preconditions: status is delivered
    //Post conditions: returns deliveryTime - orderTime
    int getMinToDelivery() throw(logic_error);

    //Preconditions: none
    //Post conditions: returns string containing orderTime and info
    string toString();


    //For testing purposes only.
    //Preconditions: none
    //Post conditions: couts order
    void display(); // ask fungai about this

    //Preconditions: none
    //Post conditions: returns status
    string getStatus();

    //Pre: none
    //Post: prints info
    void printOrder();

    friend ostream& operator << (ostream &out, Order &ord);
private:

    string info;
    Time orderTime;
    Time deliveryTime;
    int count;

    //Value is either "ordered", "departed", or "delivered"
    string status;
};
//end declaration

Order::Order()
{
    orderTime = Time();
    info = "plain";
    status = "ordered";
} //end constructor

Order::Order(Time t, string i)
{
    orderTime = t;
    info = i;
    status = "ordered";
} //end constructor

void Order::depart() throw(logic_error)
{
    if(status == "ordered")
    {
        status = "departed";
    }
    else
    {
        throw logic_error ("Already departed");
    }
} //end depart

void Order::deliver(Time t) //throw(logic_error)
{

        status = "delivered";
        deliveryTime = t;

} //end deliver

int Order::getMinToDelivery() throw(logic_error)
{
    if(status == "delivered")
    {
        return Time::elapsedMin(orderTime, deliveryTime);
    }
    else
    {
        throw logic_error ("Order not delivered");
    }
}//end getMinToDelivery

string Order::toString()
{
    string orderInfo = "Info: " + info + "\n" + "Order Time: " + orderTime.toString() + "\n" + "Status: " + status;
    if(status == "delivered")
    {
        orderInfo += "Delivery Time: " +  deliveryTime.toString() + "\n" + "Time elapsed to delivery: " + to_string(getMinToDelivery());
    }

    return orderInfo;

}//end toString

void Order::display()
{
    cout << "Info: " << info << endl;
    cout << "Status: " << status << endl;
    cout << "Order Time: " << orderTime.toString() << endl;
    if(status == "delivered")
    {
        cout << "Delivery Time: " << deliveryTime.toString() << endl;
        cout << "Time elapsed to delivery: " << getMinToDelivery() << endl;
    }

}//end display

string Order::getStatus()
{
    return status;
} //end getStatus

void Order::printOrder(){
    cout << info << endl;
} //end printOrder

ostream &operator<<(ostream &out, Order &ord) {
    ord.printOrder();
    return out;
} //end ostream operator


//end implementation




#endif //PEPPERONIPIZZADOMINATOES_ORDER_HPP
