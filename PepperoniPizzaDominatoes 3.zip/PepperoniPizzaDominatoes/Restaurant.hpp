//
// Created by Owner on 12/5/22.
//

#ifndef PEPPERONIPIZZADOMINATOES_RESTAURANT_HPP
#define PEPPERONIPIZZADOMINATOES_RESTAURANT_HPP

#include <string>
#include <deque>
#include <queue>
#include <list>
#include <iostream>
#include <queue>
#include "Order.hpp"
#include "Driver.hpp"
#include "Time.hpp"


using namespace std;

//Begin class definition
class Restaurant{
private:
    queue<Order*> orders;
    queue<Order*> readyToDeliver;
    list<Driver*> drivers;
    deque<Time*> times;
    string name;
    int numOrders;
    int numDrivers;
    int numDeliveries;
    double totalTime;
    float allTips;


public:
    //constructors
    Restaurant();
    Restaurant( string restName);

    //preconditions: none
    //postconditions: prints out the restaurant's status
    void status();

    //preconditions: none
    //postconditions: prints out summary of info about deliveries and drivers
    void summary();

    //preconditions: none
    //postconditions: returns given driver
    Driver getDriver(string names);

    //preconditions: none
    //postconditions: adds new driver
    void addDriver(Driver *driver);

    //preconditions: none
    //postconditions: adds new order
    void addOrder(Order *order, Time t1);

    //preconditions: none
    //postconditions: cooks the order so that it is ready to be delivered.
    void serveNextOrder();

    //preconditions: none
    //postconditions: assigns the order a driver and a time, so the driver can depart with that order at the given time.
    Order* departNextOrder(Driver *driver, Time t);

    //preconditions: none
    //postconditions:the driver completes the delivery at a certain time and receives a tip in dollars.
    void deliver(Driver *driver, Time time, float tip);

};
//End class definition

//Begin class implementation
Restaurant::Restaurant(string restName){
    name = restName;
    numOrders = 0;
    numDrivers = 0;
    numDeliveries = 0;
    totalTime = 0;
    allTips = 0;
}


void Restaurant::status(){
    cout << name << endl;
    cout << "Orders waiting to cook: " << endl; //loop through the queue/list for orders
    if(orders.empty()){
        cout << "no orders waiting to be cooked" << endl;
    }
    else{
        queue<Order*> tempOrder;
        for(int i = 0; i < orders.size(); i++){
            if(orders.front()->getStatus() == "ordered"){
                orders.front()->printOrder();
            }
            tempOrder.push(orders.front());
            orders.pop();
        }

        for(int i = 0; i < tempOrder.size(); i++){
            orders.push(tempOrder.front());
            tempOrder.pop();
        }
    }
    //and drivers and print out the statuses.
    //output time and order
    //cout << orders.display() << endl;
    cout << "Orders waiting to deliver: " << endl;
    if(readyToDeliver.empty()){
        cout << "no orders waiting to deliver" << endl;
    }
    else{
        queue<Order*> tempOrder;
        for(int i = 0; i < readyToDeliver.size(); i++){
            readyToDeliver.front()->printOrder();
            tempOrder.push(readyToDeliver.front());
            readyToDeliver.pop();
        }

        for(int i = 0; i < tempOrder.size(); i++){
            readyToDeliver.push(tempOrder.front());
            tempOrder.pop();
        }
    }
    //output time and order
    //cout << " " << endl;
    cout << "Drivers: " << endl;
    if(drivers.empty()){
        cout << "no drivers logged in" << endl;
    }
    else {
        list<Driver*> tempDriver;
        int size = drivers.size();
        for (int i = 0; i < size; i++) {
            //cout driver name
            cout << drivers.front()->getName() << ": " << endl;
            //cout driver status
            if (!drivers.front()->isloggedIn()) {
                cout << "Not logged in" << endl;
            } else {
                if (drivers.front()->isDriverDelivering()) {
                    cout << "Delivering: ";
                    drivers.front()->printOrder();
                } else if (drivers.front()->isDriverDriving()) {
                    cout << "Driving" << endl;
                } else {
                    cout << "Waiting for order" << endl;
                }
            }
                //cout orders being delivered by that driver at the time if any
                tempDriver.push_back(drivers.front());
                drivers.pop_front();
        }
        for (int i = 0; i < size; i++){
            drivers.push_back(tempDriver.front());
            tempDriver.pop_front();
        }
    }
    //output driver, time and order
    //cout << " " << endl;
}

void Restaurant::summary(){
    cout <<"Number of orders completed: " << numOrders << endl;
    cout <<"Average time per order: " << (totalTime / numDeliveries) << endl;
    list<Driver*> tempDriver;

    int s = drivers.size();
    for(int i = 0; i < s; i++){
        Driver* drive = drivers.front();
        cout << "Driver " << drive->getName() << ":" << endl;
        cout << "Number of deliveries completed: " << drive->getTotalDelivs() << endl;
        cout << "Average time per delivery: " << (drive->getTotalDelivMins() / drive->getTotalDelivs()) << endl;
        cout << "Total driving time: " << drive->getTotalDriveMins() << endl;
        cout << "Total Tips: " << drive->getTotalTips()<< endl; //just uncommented this (12/7/2022)
        tempDriver.push_back(drivers.front());
        drivers.pop_front();
    }

    for(int i = 0; i < s; i++){
        drivers.push_back(tempDriver.front());
        tempDriver.pop_front();
    }
    //drivers.push_back(tempDriver);
    //cout << "Number of orders completed: " << call number of orders << endl;
    //cout << "Average time per order: " << call average time << endl;
    //call to print out all drivers and all their statuses
    //cout << summary() << endl; //how to do this?
}

Driver Restaurant :: getDriver(string names) {
    //iterate through drivers, return iterator once name is matched
    for (auto iterator = drivers.begin(); iterator != drivers.end(); iterator++) {
        auto driverToPrint = *iterator;
        cout << "\t" << driverToPrint->getName() << " " << driverToPrint->getStatus() << " "; //ask about LoginTime
        if (driverToPrint->getStatus() == "At Restaurant") {
            cout << "At Restaurant" << endl;
        } else if (driverToPrint->getStatus() == "Ready for delivery") {
            cout << "Ready for Delivery";//cout << driverToPrint->getOrder() << endl;
        } else if (driverToPrint->getStatus() == "Currently on a delivery") {
            cout << " Currently on a delivery";//cout << driverToPrint->getOrder() << endl;
        } else if (driverToPrint->getStatus() == "En route back to store") {
            cout << " En route back to store";//cout << driverToPrint->getOrder() << endl;
            return **iterator;
        }
    }
}

void Restaurant::addDriver(Driver *driver){
    drivers.push_back(driver);
    numDrivers ++;

}

void Restaurant::addOrder(Order *order, Time time ){
    orders.push(order);
    numOrders++;

}

void Restaurant::serveNextOrder(){
    Order* temp;
    temp = orders.front();
    orders.pop();
    readyToDeliver.push(temp);
}

Order* Restaurant::departNextOrder(Driver *driver, Time t){
    //remove top order from queue, and return order
    Order* orderTop = readyToDeliver.front();
    readyToDeliver.pop();
    driver->depart(t, orderTop);
    //driver->getStatus(); // maybe?
    return orderTop;
    //return o;
}

void Restaurant::deliver(Driver *driver, Time time, float tip){// update the total tips, and update the total time on deliveries
    //driver.getTotalTips();
    //string timeGet = time.getTime();
    //driver.getName(); //try this maybe
    //driver.getTotalDelivMins(); //try this maybe
    //driver->elapsedMin( , timeGet);
    driver->delivered(time, tip);
    int temp = driver->getOrder()->getMinToDelivery();
    numDeliveries++;
    //driver.addTip(tip);
    allTips += tip;
    totalTime = totalTime + temp;
}

Restaurant::Restaurant() {
    name = "default";
}

/*
ostream &operator<<(ostream &out, Restaurant &rest) {
    rest.summary();
    return out;
}
 */
//end class implementation




#endif //PEPPERONIPIZZADOMINATOES_RESTAURANT_HPP
