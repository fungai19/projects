#include <iostream>
#include "Time.hpp"
#include "Driver.hpp"
#include "Order.hpp"
#include "Restaurant.hpp"

using namespace std;


int main() {

    Restaurant res1("Money Team Pizza Shop");
    Driver dan("Dan");
    Driver ada("Ada");
    res1.addDriver(&dan);
    res1.addDriver(&ada);

    Time time1(10, 00);
    Time time2(10, 15);
    Time time3(10, 30);
    Time time4(10, 45);
    Time time5(11, 00);
    Time time6(11,45);
    Time time7(12,15);
    Time time8(12,55);
    Order order1(time1, "3 Margherita Pizzas to 308 Arroyo Lane");
    res1.addOrder(&order1, time1);
    dan.login();

    res1.serveNextOrder();
    res1.departNextOrder(&dan, time2);
    Order order2(time3, " 1 Buffalo Chicken Sandwich to 123 Sesame Street");
    res1.addOrder(&order2, time3);
    ada.login();
    Order order3(time4, "16 Pineapple Pizzas to 48 CranjusMcBasketBall Court");
    res1.addOrder(&order3, time4);
    res1.serveNextOrder();

    res1.departNextOrder(&ada, time5);

    res1.serveNextOrder();


    cout << "Report: "<< endl;
    res1.status();
    cout << endl;

    res1.deliver(&dan, time4, 3.75);
    dan.arrive(time5);

    res1.deliver(&ada, time6, 5.10);
    ada.arrive(time8);

    res1.departNextOrder(&dan, time6);
    res1.deliver(&dan, time7, 2.50);
    dan.arrive(time8);


   /* Time time6(20, 00);
    Time time7(20, 35);
    Time time8(21, 00);
    Time time9(21, 45);
    Time time10(23, 00);

    Order order4(time6, "2 cheese to 120 West Mango Lane");
    res1.addOrder(&order4, time6);
    //dan.login();

    res1.serveNextOrder();
    res1.departNextOrder(&dan, time7);
    Order order5(time8, "7 goats to 140 Milner Avenue");
    res1.addOrder(&order5, time8);
    //ada.login();
    Order order6(time9, "12 bears to 12 Honey Badger Aquarium");
    res1.addOrder(&order6, time9);
    res1.serveNextOrder();

    cout << "Report 2: "<< endl;
    res1.status();
    cout << endl;

    res1.deliver(&dan, time4, 2.50);
    dan.arrive(time5);




    cout << "Report 3: "<< endl;
    */
    //res1.status();
    //cout << endl;
    //cout<< "\nSummary:\n";



    res1.summary();



    return 0;
}



