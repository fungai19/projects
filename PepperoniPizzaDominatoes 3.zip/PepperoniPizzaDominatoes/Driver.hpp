//
// Created by Owner on 12/5/22.
//

#ifndef PEPPERONIPIZZADOMINATOES_DRIVER_HPP
#define PEPPERONIPIZZADOMINATOES_DRIVER_HPP

#include <stdexcept>
#include <iostream>
#include "Time.hpp"
#include "Order.hpp"
#include <cstdlib>
#include <iomanip>
#include <cassert>

using namespace std;

class Driver {

private:
    string name;
    Time timeDeparted;
    Time timeArrived;
    Time timeDelivered;
    Order* order;
    float totalTip;
    bool isLoggedin;
    bool isDriving;
    bool isDelivering;
    int totalDelivs;
    int totalMinsDriving;
    int totalMinsDelivering;


public:
    //preconditions: none
    //postconditions:creates a logged-in driver with a given name
    Driver (string newDriverName);

    //preconditions:driver is not logged in
    //postconditions: logs the driver in
    void login() throw (logic_error);

    //preconditions: driver is logged in and at the restaurant
    //postconditions:logs the driver out
    void logout() throw (logic_error);

    //preconditions:driver is logged in and at the restaurant
    //postconditions: driver is delivering, departure time recorded
    void depart(Time t, Order* o) throw (logic_error);

    //preconditions:driver is delivering, tip is greater than or equal to 0
    //postconditions: driver is not delivering, the driver stats are updated
    void delivered (Time t, float tip) throw (logic_error);

    //preconditions: none
    //postconditions: driver is at the restaurant, driver's stats are updated (ready for order).
    void arrive (Time t);

    //preconditions:none
    //postconditions:returns the driver's name
    string getName();

    //preconditions:none
    //postconditions:returns true if the driver is logged in, false otherwise
    bool isloggedIn();

    //preconditions: none
    //postconditions: returns the total number of deliveries completed
    int getTotalDelivs();

    //preconditions: none
    //postconditions: returns total minutes spent delivering between depart and deliver commands
    int getTotalDelivMins();

    //preconditions:none
    //postconditions:returns the total minutes spent driving difference between depart and arrive commands.
    int getTotalDriveMins();

    //preconditions:none
    //postconditions:returns the total tips received .
    float getTotalTips();

    //pre: none
    //post: returns if driver is delivering
    bool isDriverDelivering();

    //pre: none
    //post: returns if driver is driving
    bool isDriverDriving();

    //preconditions:none
    //postconditions:returns the order being delivered.
    Order* getOrder () ;

    //pre: driver is delivering
    //post: prints the order being delivered
    void printOrder() throw (logic_error);

    //preconditions: driver must be logged in
    //postconditions: returns the driver's status
    string getStatus() throw (logic_error);

    //preconditions: none
    //postconditions: returns a string containing the driver's name,
    // status and,
    // if the driver is delivering an order,
    // the departure time and toString of the order being delivered.
    string toString();

    //precondition:none
    //postconditions: updates the total tip amount in dollars.
    void addTip(float tip);



};

Driver::Driver(string newDriverName) {
    name = newDriverName;
    isLoggedin = false;
    totalTip = 0;
    totalDelivs = 0;
    totalMinsDriving = 0;
    totalMinsDelivering = 0;
}

void Driver::login() throw (logic_error) {
    if (isLoggedin == true)
    {
        throw logic_error("Driver must not be logged in");
    }
    else
    {
        isLoggedin = true;
        isDelivering = false;
        isDriving = false;
    }

}

void Driver::logout() throw (logic_error){
    if (isLoggedin == false)
    {
        throw logic_error("Driver must be logged in");
    }
    if (isDriving == true){
        throw logic_error("Driver must be at the restaurant");
    }
    //if(isDelivering == true)
   // {
        //throw logic_error("Driver must be at the restaurant");
    //}
    else
    {
        isLoggedin = false;
    }

}

void Driver::depart(Time t, Order* o) throw (logic_error){
    if (isLoggedin == false)
    {
        throw logic_error("Driver must be logged in");
    }

    else
    {
        isDelivering = true;
        order = o;
        timeDeparted = t;
        isDriving = true;
        isDelivering = true;
    }

}

void Driver::delivered(Time t, float tip) throw (logic_error) {
    if(isDelivering == false)
    {
        throw logic_error("Driver must have been delivering");
    }
    if (totalTip < 0)
    {
        throw logic_error("Tip must be >= 0");
    }
    else
    {
        isDelivering = false;
        totalDelivs ++;
        totalTip = totalTip + tip;
        order->deliver(t);
        timeDelivered = t;
    }

}

void Driver::arrive(Time t) {

        isDriving = true;
        isDelivering = false;
        timeArrived = t;
        totalMinsDelivering = totalMinsDelivering + Time::elapsedMin(timeDeparted, timeDelivered);
        totalMinsDriving = totalMinsDriving + Time::elapsedMin(timeDeparted, timeArrived);
        //Time::elapsedMin(timeDeparted, timeArrived);

        //caluclate total time spent driving here


}

string Driver::getName() {
    return name;
}

bool Driver::isloggedIn() {
    return isLoggedin;
}

int Driver::getTotalDelivs() {
    return totalDelivs;
}

int Driver::getTotalDelivMins() {
    //int t = abs(timeDeparted - timeDelivered);
    //return t;
    //return Time::elapsedMin(timeDeparted, timeDelivered);
    return totalMinsDelivering;
}

int Driver::getTotalDriveMins() {
    //int t = abs(timeDeparted - timeArrived);
    //return t;
    //return Time::elapsedMin(timeDeparted, timeArrived);
    return totalMinsDriving;
}

float Driver::getTotalTips() {
    return totalTip;
}

bool Driver::isDriverDriving() {

    return isDriving;
}

bool Driver::isDriverDelivering() {
    return isDelivering;
}

Order *Driver::getOrder()  {
    return order;
}

void Driver::printOrder() throw (logic_error){
    if(!isDelivering){
        throw logic_error ("Driver must be delivering to print an order");
    }
    string orderToCout = order->toString();
    cout << orderToCout << endl;
}

string Driver::getStatus() throw (logic_error){
    string status;
    if(!isLoggedin) {
        throw logic_error("Driver must be logged in to have a status");
    }
    if(isDelivering == false && isDriving == false)
    {
        status = "At Restaurant";
    }
    else if(isDelivering == true && isDriving == false)
    {
        status = "Ready for delivery";
    }
    else if(isDelivering == true && isDriving == true)
    {
        status = "Currently on a delivery";
    }
    else if(isDelivering == false && isDriving == true)
    {
        status = "En route back to store";
    }
    return status;

}

string Driver::toString() {

    string tempo;
    tempo = tempo + getName() + "\n";
    if (isLoggedin == true) {
        tempo = tempo + "Logged In \n";
    }
    else
    {
        tempo = tempo + "Logged Out \n";
    }
    if (isDelivering == true)
    {
        tempo = tempo + "Is Delivering \n";
    }
    else
    {
        tempo = tempo + "Is not delivering \n";
    }
    if (isDriving == true)
    {
        tempo = tempo + "Is driving \n";
    }
    else
    {
        tempo = tempo + "Is not yet driving \n";
    }
    return tempo;



    /*
    string driverInfo = "Info: " + name + "\n" + "Driver Status: " + isLoggedin + "\n" + "Driving Status: " + isDriving + "\n" +
                        "Delivery Status: " + isDelivering + "\n" + "Departure Time: " + timeArrived.toString() + "\n" + "Order: " + order.toString();
    if(isLoggedin = true)
    {
        driverInfo += "Driver Name: " +  name + "\n" + "Driver Status " + isLoggedin.toString();
    }
    if(isDelivering = true)
    {
        driverInfo += "Driver Name: " +  name + "\n" + "Driver Status " + isLoggedin.toString() + "\n" + "Delivery Status: " + isDelivering.toString()  + "\n" + "Departure Time: " + timeArrived.toString() + "\n" + "Order: " + order.toString();
    }
    if(isDriving = true)
    {
        driverInfo += "Driver Name: " +  name + "\n" + "Driver Status " + isLoggedin.toString() + "\n" + "Delivery Status: " + isDelivering.toString()  + "\n" + "Departure Time: " + timeArrived.toString() + "\n" + "Order: " + order.toString();
    }
    */
}

void Driver::addTip(float tip) {

    totalTip+= tip;

}


#endif //PEPPERONIPIZZADOMINATOES_DRIVER_HPP
