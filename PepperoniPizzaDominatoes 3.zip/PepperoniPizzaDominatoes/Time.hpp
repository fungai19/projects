//
// Created by Owner on 12/5/22.
//

#ifndef PEPPERONIPIZZADOMINATOES_TIME_HPP
#define PEPPERONIPIZZADOMINATOES_TIME_HPP
using namespace std;

#include <stdexcept>
#include <iostream>
#include <cstdlib>

class Time {

public:
    //preconditions: none
    //postconditions: this is the default constructor that creates a Time object with default values
    Time();

    //preconditions: 0 <= hours <= 23, 0 <= minutes <= 59
    //postconditions: creates a Time object with a specific hour and minute.
    Time(int hour, int min) throw (logic_error);

    //Preconditions: none
    //Postconditions: Returns hour
    int getHour();

    //Preconditions: none
    //Postconditions: returns minute;
    int getMinute();


    //preconditions: none
    //postconditions: returns time in HH:MM
    string getTime()const;

    //preconditions:none
    //postconditions:returns the difference in minutes between t2 and t1
    static int elapsedMin(Time t1, Time t2);

    //Preconditions: none
    //Post conditions: returns string containing orderTime and info
    string toString();

    //Preconditions: none
    //Postconditions: overloaded output operator
    friend ostream& operator << (ostream &out, Time &t);


private:
    int hour;

    int min;


}; //end declaration

Time::Time()
{
    hour = 0;
    min = 0;

} // end default constructor

Time::Time(int hour, int min) throw (logic_error)
{
    if(hour < 0 || hour > 24 || min < 0 || min > 59)
    {
        throw logic_error("Invalid Hour");
    } // end if
    this->hour = hour;  //references hour of the class itself
    this->min = min;  //references minute of the class itself

}

int Time::elapsedMin(Time t1, Time t2)
{
    int t1TotalMin = t1.hour * 60 + t1.min;
    int t2TotalMin = t2.hour * 60 + t2.min;

    return abs(t2TotalMin - t1TotalMin);
} // end elapsedMin


string Time::getTime() const
{
    string TimeGetter (hour, min);
    return TimeGetter;
} // end getTime


string Time::toString()
{
    string outputString = "";
    outputString = to_string(getHour()) + ":";
    if (getMinute() < 10)
        outputString += "0"; //This allows for 4:07, 3:09, etc.
    outputString += to_string(getMinute());
    return outputString;
}

int Time::getHour() {
    return hour;
}

int Time::getMinute() {
    return min;
}

ostream &operator<<(ostream &out, Time &t) {
    string hrs = to_string(t.hour);
    string mins = to_string(t.min);

    if(hrs.length() == 1)
    {
        hrs = hrs;
    }
    if(mins.length() == 1)
    {
        mins = mins;
    }

    out << hrs << ':' << mins;

    return out;
}
//end implementation



#endif //PEPPERONIPIZZADOMINATOES_TIME_HPP
