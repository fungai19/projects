//
// Created by Fungai Jani on 11/9/2022.
//
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <cassert>
#include <cstring>
#include "Text.h"

//--------------------------------------------------------------------
// Creates a string containing the delimited sequence of characters
// charSeq. Allocates enough memory for this string.
// Pre: none
// Post: creates a Text object containing the array pointed to by charSeq
Text:: Text ( const char *charSeq )
{
    bufferSize = strlen(charSeq) + 1;   // Account for null

    try
    {
        buffer = new char [ bufferSize ];   // Allocate memory
    }
    catch ( bad_alloc &e )
    {
        cerr << "Text::Text(const char): bad_alloc: buffer == 0\n";
        throw bad_alloc();
    }

    strcpy(buffer,charSeq);             // Copy the string
}

Text:: Text ( const Text &valueText )
: bufferSize(valueText.bufferSize)
{
    buffer = new char [bufferSize];
    strcpy(buffer, valueText.buffer);
}

//--------------------------------------------------------------------
void Text:: operator = ( const Text& other )
// Assigns other to a Text object.

{
if (this != &other) {
int rlen = other.getLength();   // Length of other

if ( rlen >= bufferSize )       // If other will not fit
{
delete [] buffer;            // Release buffer and
bufferSize = rlen + 1;             //  allocate a new
buffer = new char [ bufferSize ];  //  (larger) buffer
}

strcpy(buffer, other.buffer);    // Copy other’s buffer
bufferSize = other.bufferSize;  // Copy other’s bufferSize
}
}

//--------------------------------------------------------------------
Text:: ~Text ()
{
delete [] buffer;
}


//--------------------------------------------------------------------
int Text:: getLength () const
{
    return bufferSize - 1;
}

//--------------------------------------------------------------------
char Text:: operator [] ( int n ) const
{
    if (n > 0 && n < bufferSize)
            return buffer[n];
    else
        return '\0';
}

//--------------------------------------------------------------------
void Text:: clear ()
{
    delete [] buffer;
    buffer[0] = '\0';
    bufferSize = 1;

    buffer = new char [bufferSize];
}

//--------------------------------------------------------------------
void Text:: showStructure () const
{
    // Outputs the characters in a string. This operation is intended for
// testing/debugging purposes only.

    {
        int j;   // Loop counter

        for ( j = 0 ; j < bufferSize ; j++ )
            cout << j << "\t";
        cout << endl;
        for ( j = 0 ; buffer[j] != '\0' ; j++ )
            cout << buffer[j] << "\t";
        cout << "\\0" << endl;
    }
}

//--------------------------------------------------------------------
//
//                        In-lab operations
//
//--------------------------------------------------------------------
istream & operator >> ( istream &input, Text &inputText )
{
   input >> inputText.buffer;
    return input;
}

//--------------------------------------------------------------------
ostream & operator << ( ostream &output, const Text &outputText )
{
    output << outputText.buffer;
    return output;
}


//--------------------------------------------------------------------
Text Text:: toUpper ( ) const
{
    Text temp(buffer);
    for(int i = 0; i < bufferSize; i++){
        if((buffer[i] > 96) && (buffer[i] < 123)){
            temp.buffer[i] = char(buffer[i] - 32);
        }
    }
    return temp;
}

//--------------------------------------------------------------------
Text Text:: toLower ( ) const
{
    Text temp(buffer);
    for(int i=0; i < bufferSize; i++) {
        if((buffer[i] > 64) && (buffer[i] < 91)){
            temp.buffer[i] = char(buffer[i] + 32);
        }
    }
    return temp;
}


//--------------------------------------------------------------------
bool Text::operator == ( const Text &other ) const {
    if (bufferSize != other.getLength()) {
        if (bufferSize == 0) {
            return true;
        } else {
            for (int i = 0; i < bufferSize; i++) {
                if (buffer[i] != other.buffer[i]) {
                    return false;
                }
            }
            return true;
        }
    }
        else{
            return false;
        }
    return false;
    }


//--------------------------------------------------------------------
bool Text::operator < ( const Text &other ) const
{
    if(other.getLength()){
        if(bufferSize){
            for(int i = 0; i < bufferSize; i++){
                if(buffer[i] > other.buffer[i]){
                    return false;
                }

            }
            if((other.getLength() < bufferSize) || (other.getLength() == bufferSize)){
                return false;
            }
            else{
                return true;
            }
        }
    }
    return false;

}

//--------------------------------------------------------------------files for students
bool Text::operator > ( const Text &other ) const
{
    if(bufferSize){
        if(other.getLength()){
            for(int i = 0; i < other.getLength(); i++){
                if(buffer[i] < other.buffer[i]){
                    return false;
                }
            }
            if((other.getLength() > bufferSize) || (other.getLength() == bufferSize)){
                return false;
            }
            else{
                return true;
            }

        }
        else{
            return true;
        }
    }
    return false;
}


#include "Text.h"
