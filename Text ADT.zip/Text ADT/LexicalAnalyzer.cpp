//
// Created by Fungai Jani on 14/9/2022.
//
#include <fstream>
#include <string>
#include <iostream>

using namespace std;
#include "Text.h"

/* A command-line user interface that allows the user to read in a file
 * containing a program consisting of words or tokens separated by whitespace.
 * Requirements: none
 * Results: For each word in the file specified by the user (including any
 * blank lines), each word is printed out on a new line in the form 1: [word1], where 1
 * is a counter indicating the current number of the word and word is the ith
 * token in the file.
 *
 */
int main33() {
    /*** YOUR CODE HERE ***/
    /**********************/
    int count = 0;
    //set up counter variable to 0

    Text token; // Text object that can hold a word
    string fileName;
    cout << "Enter a file name: ";
    cin >> fileName;

    ifstream in;				// Object representing input from a file.
    in.open(fileName.c_str());		// Open the file for reading.
    if (in.is_open()) {

        while( in >> token )
        {
            /*** YOUR CODE HERE ***/
            /**********************/
            count++;
            // Increment your word counter.

            /*** YOUR CODE HERE ***/
            /**********************/
            cout << count<< " : " << token << endl;
            // Print word as specified in requirements


        }//end while
        in.close();		// Close the file.

    } else {
        cout << "Error: Couldn't read " << fileName << endl;

    }
}
